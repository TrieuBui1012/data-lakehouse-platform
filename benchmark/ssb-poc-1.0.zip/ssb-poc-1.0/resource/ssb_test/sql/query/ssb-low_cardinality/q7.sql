--Q7
select count(*) from lineorder_flat group by lo_shipmode,lo_orderdate;
