--Q1
select count(*),lo_shipmode from lineorder_flat group by lo_shipmode;
