--Q2
select count(distinct lo_shipmode) from lineorder_flat;
