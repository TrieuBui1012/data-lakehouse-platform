--Q6
select count(*) from lineorder_flat group by c_city,s_city;
