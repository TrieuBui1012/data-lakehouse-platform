--Q9
select count(*) from lineorder_flat group by c_city,s_city,c_nation,s_nation;
